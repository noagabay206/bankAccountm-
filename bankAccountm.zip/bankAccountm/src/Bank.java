import java.util.ArrayList;
import java.util.List;

public class Bank  implements IBank{

    List<IAccount> BankList ;
    public Bank() {
        this.BankList =new ArrayList<>();
    }
    @Override
    public void OpenAccount(IAccount account) {
        this.BankList.add(account);
    }

    @Override
    public void CloseAccount(int accountNumber) {

        for (int i=0; i<= this.BankList.size(); i++)
        {
            if (this.BankList.get(i).GetAccountNumber()==accountNumber)
            {
                double currentBalance = this.BankList.get(i).GetCurrentBalance();
                if (currentBalance>=0) {
                    this.BankList.remove(i);
                }
                else {
                    System.out.println("The account is not closed due to debt.");
                }

            }

        }
    }

    @Override
    public List<IAccount> GetAllAccounts() {

        return this.BankList;
    }

    @Override
    public List<IAccount> GetAllAccountsInDebt() {
        List<IAccount> DebtBank = new ArrayList<>() ;
        for (int i=0; i<= this.BankList.size(); i++)
        {
            double currentBalance = this.BankList.get(i).GetCurrentBalance();
            if (currentBalance<0) {
                DebtBank.add(this.BankList.get(i));
            }

        }
        return DebtBank;
    }

    @Override
    public List<IAccount> GetAllAccountsWithBalance(double balanceAbove) {
        List<IAccount> BalanceBank   = new ArrayList<>();

        for(int i=0; i<= this.BankList.size(); i++)
        {
            double currentBalance = this.BankList.get(i).GetCurrentBalance();
            if (currentBalance>=balanceAbove) {
                BalanceBank.add(this.BankList.get(i));
            }



        }
        return BalanceBank;
    }
}
