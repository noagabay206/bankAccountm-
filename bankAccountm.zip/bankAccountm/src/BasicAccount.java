import javax.swing.plaf.basic.BasicOptionPaneUI;

public class BasicAccount implements  IAccount {

    int numberAccount;
    double limitWithDraw;

    double balance;


    public BasicAccount(int accountNumber, double withdrawaLimit){

        this.numberAccount=accountNumber;
        this.limitWithDraw=withdrawaLimit;
        balance=0.0;
    }

    @Override
    //deposit balance = balnce +amount
    public void Deposit(double amount) {

        balance+= amount;
    }

    @Override
    //remove the amount from the balance
    public double Withdraw(double amount) {
        if (amount <= balance)
        {
            if (amount>this.limitWithDraw) {
                balance -= limitWithDraw;
                return limitWithDraw;
            }
            else {
                balance-=amount;
                return amount;
            }
        }
        return 0;
    }

    @Override
    public double GetCurrentBalance() {
        return balance;
    }

    @Override
    public int GetAccountNumber() {
        return this.numberAccount;
    }
}